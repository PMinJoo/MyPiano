#include <iostream>
#include <string>
#include <fstream>
#include "playsound.h"
#include <opencv2/opencv.hpp>

using namespace cv;
using namespace std;



void cvt_to_gray(Mat input_img, Mat output_img);

int cal_interval(int line[], int lineNum);

void remove_noise(Mat img_new, Mat mask);

int cal_interval(int line[], int lineNum);

void output_all(int nlabels, string point_string[]);

void output_part(int interval_position_count, string point_string[], int interval_position[], int nlabels);

void remove_noise(Mat img_new, Mat mask);

int cognize_SM(string path);
